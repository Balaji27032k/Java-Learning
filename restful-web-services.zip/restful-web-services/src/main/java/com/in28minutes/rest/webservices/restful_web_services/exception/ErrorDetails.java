package com.in28minutes.rest.webservices.restful_web_services.exception;

import java.time.LocalDateTime;

public class ErrorDetails {
	private LocalDateTime localDateTime;
	private String details;
	private String message;
	
	public ErrorDetails(LocalDateTime localDateTime, String details, String message) {
		super();
		this.localDateTime = localDateTime;
		this.details = details;
		this.message = message;
	}
	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}
	public String getDetails() {
		return details;
	}
	public String getMessage() {
		return message;
	}
	
}
