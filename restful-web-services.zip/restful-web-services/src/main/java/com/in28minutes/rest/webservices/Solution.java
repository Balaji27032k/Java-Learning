package com.in28minutes.rest.webservices;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		removeDuplicates(new int[] {1,1,2});
	}

	public static int removeDuplicates(int[] nums) {
		int j = 1;
		for (int i = 1; i < nums.length; i++) {
			if (nums[i] != nums[i - 1]) {
				nums[j] = nums[i];
				j++;
			}
		}
		return j;
	}
}
