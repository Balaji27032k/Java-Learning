package com.in28minutes.rest.webservices.restful_web_services.versioning;

public class Name {
	private String firstName,lastNameString;

	public Name(String firstName, String lastNameString) {
		super();
		this.firstName = firstName;
		this.lastNameString = lastNameString;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastNameString() {
		return lastNameString;
	}

	@Override
	public String toString() {
		return "Name [firstName=" + firstName + ", lastNameString=" + lastNameString + "]";
	}
	
	
}
